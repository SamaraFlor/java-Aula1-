
public class PE04 {

	public static void main(String[] args) {
		ContaCorrente cc1 = new ContaCorrente();
		ContaCorrente cc2 = new ContaCorrente(002,1000.00);
		
		cc1.setNumCC(003);
	    cc1.setSaldoCC(2000.00);
	    
	    cc1.sacar(100);
	    cc1.depositar(1000);
	    
	    cc2.sacar(200);
	    cc2.depositar(1390);

		
		System.out.println(
				"CC N..:" + cc1.getNumCC() +
			   " Saldo......:" + cc1.getSaldoCC()
				);
		
		System.out.println(
				"CC N..:" + cc2.getNumCC() +
			   " Saldo......:" + cc2.getSaldoCC()
				);
	   
	}

}
