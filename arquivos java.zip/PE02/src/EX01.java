
public class EX01 {

	public static void main(String[] args) {
		 Funcionarios F01 = new Funcionarios();
		 Funcionarios F02 = new Funcionarios(); 
		 F01.setCodFuncionario(1200);
		 F01.setNomeFunc("Maria Antonia Guimar�es");
		 F01.setSalarioMensal(8600.00);
	
		   System.out.println("Codigo \t\t Nome \t\t\t\t Salario");
		   System.out.println(F01.getCodFuncionario()  + "\t\t"+ 
		                      F01.getNomeFunc() + "\t\t"+ 
				              F01.getSalarioMensal());

		   System.out.println(F02.getCodFuncionario()  + "\t\t"+ 
		                      F02.getNomeFunc() + "\t\t"+ 
				              F02.getSalarioMensal());
		   
		   F01.setAumento(15.0);
		   F02.setAumento(15.0);

		   System.out.println("\nSalario Anual");
		   System.out.println("Codigo \t\t Nome");
		   System.out.println(F01.getCodFuncionario() + "\t\t" +
		                      F01.getSalarioAnual());
		   
		   System.out.println(F02.getCodFuncionario() + "\t\t" +
		                      F02.getSalarioAnual());
	}
}




