
public class Funcionarios {
      private int codFuncionario;
      private String nomeFunc;
      private double salarioMensal;
   
      
        public Funcionarios() {
       }
    	 
        public Funcionarios(int codFuncionario, String nomeFunc, double salarioMensal) {
		this.nomeFunc = nomeFunc;
		this.salarioMensal = salarioMensal;
		
	}

		public int getCodFuncionario() {
			return codFuncionario;
		}


		public void setCodFuncionario(int codFuncionario) {
			this.codFuncionario = codFuncionario;
		}


		public String getNomeFunc() {
			return nomeFunc;
		}


		public void setNomeFunc(String nomeFunc) {
			this.nomeFunc = nomeFunc;
		}


		public double getSalarioMensal() {
			return salarioMensal;
		}


		public void setSalarioMensal(double salarioMensal) {
			this.salarioMensal = salarioMensal;
		}
         
   
		public double getSalarioAnual() {
			return this.salarioMensal * 12;
		}
		
		public void setAumento (double per) {
			this.salarioMensal = this.salarioMensal * (1.0 + per/100.0);
		}

		
  	}
  









