
public class PE05{

	public static void main(String[] args) {
		 
		AlunoDisciplina alunoA = new AlunoDisciplina();
		AlunoDisciplina alunoB = new AlunoDisciplina(001,456,2.6,5.00);
	
		alunoA.setIdAluno(2);
		alunoA.setIdDisciplina(546);
		alunoA.setNotaB1(5.78);
		alunoA.setNotaB2(3.45);
		
		alunoA.mediaAritmetica();
		alunoA.mediaPonderada();
		
		System.out.println("Historico aluno" + alunoA.getIdAluno() + "\n" + alunoA.getIdDisciplina() + 
				                        "\n" +  alunoA.getNotaB1() + "\n " + alunoA.getNotaB2());
		                                    
		System.out.println("media Aritimetica  " + alunoA.mediaAritmetica()+ "\n "
				          + "media Ponderada:   " + alunoA.mediaPonderada());
		
		
		System.out.println("////////////////////////////////////////////////////////////////////////////"
				           + "Historico aluno B  " + alunoB.getIdAluno() + "\n" + alunoB.getIdDisciplina() + 
                            "\n" +  alunoB.getNotaB1() + "\n " + alunoB.getNotaB2());
                    
       System.out.println("\n " + "media Aritimetica  " + alunoB.mediaAritmetica()+ "\n "
                        + "media Ponderada:   " + alunoB.mediaPonderada());


	}

}
